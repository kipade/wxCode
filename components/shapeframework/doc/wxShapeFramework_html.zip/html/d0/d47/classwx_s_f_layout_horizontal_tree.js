var classwx_s_f_layout_horizontal_tree =
[
    [ "wxSFLayoutHorizontalTree", "d0/d47/classwx_s_f_layout_horizontal_tree.html#a6200cb1130d70911aad31dd1e55ddcbf", null ],
    [ "~wxSFLayoutHorizontalTree", "d0/d47/classwx_s_f_layout_horizontal_tree.html#a9027b93d857a54eb7610b74e756f19b8", null ],
    [ "DoLayout", "d0/d47/classwx_s_f_layout_horizontal_tree.html#a80faaa33e9df2fc128e4b8e537e82ce9", null ],
    [ "GetHSpace", "d0/d47/classwx_s_f_layout_horizontal_tree.html#a0ab5aa9e65126ce99454a50b4c344e65", null ],
    [ "GetVSpace", "d0/d47/classwx_s_f_layout_horizontal_tree.html#ac012404dfdbf46978e31a1d5b2df840d", null ],
    [ "ProcessNode", "d0/d47/classwx_s_f_layout_horizontal_tree.html#a854893e16299cdfeb7a35efab93f07c1", null ],
    [ "SetHSpace", "d0/d47/classwx_s_f_layout_horizontal_tree.html#afbeb1a72d582bfb79aa32d9db0470b30", null ],
    [ "SetVSpace", "d0/d47/classwx_s_f_layout_horizontal_tree.html#a1fb0d968905bb16197e1eab39fd44267", null ],
    [ "m_HSpace", "d0/d47/classwx_s_f_layout_horizontal_tree.html#a4b86aa57631c57b5219f9ff5fa5398e3", null ],
    [ "m_nCurrMaxHeight", "d0/d47/classwx_s_f_layout_horizontal_tree.html#abffbc24598d64585da3cdcad8ee8d97e", null ],
    [ "m_nMinY", "d0/d47/classwx_s_f_layout_horizontal_tree.html#abb9d5905eaf30633d564e72e766d23db", null ],
    [ "m_VSpace", "d0/d47/classwx_s_f_layout_horizontal_tree.html#ac49e510b5a0f7f189f7757a44658b2ee", null ]
];