var classwx_s_f_shape_paste_event =
[
    [ "wxSFShapePasteEvent", "d0/d11/classwx_s_f_shape_paste_event.html#abd148170d2a9ca213221dc549d0faef0", null ],
    [ "wxSFShapePasteEvent", "d0/d11/classwx_s_f_shape_paste_event.html#a36cad9da01eedd4a6eb6402dceb43542", null ],
    [ "~wxSFShapePasteEvent", "d0/d11/classwx_s_f_shape_paste_event.html#ab578a3067082134316a27b975fc2b3a1", null ],
    [ "Clone", "d0/d11/classwx_s_f_shape_paste_event.html#af486244699fc519f5d450a7157fea9cf", null ],
    [ "GetDropTarget", "d0/d11/classwx_s_f_shape_paste_event.html#a6b7092014ffd67eb1bbcfd91d126b328", null ],
    [ "GetPastedShapes", "d0/d11/classwx_s_f_shape_paste_event.html#a30b77b5120c3c6efd80ad6586744321e", null ],
    [ "SetDropTarget", "d0/d11/classwx_s_f_shape_paste_event.html#a01ee96c5f622d7c50f7c86ef84ea9fdd", null ],
    [ "SetPastedShapes", "d0/d11/classwx_s_f_shape_paste_event.html#ab7aee9adeaf739b0190ad6ca3e3727c4", null ],
    [ "m_lstPastedShapes", "d0/d11/classwx_s_f_shape_paste_event.html#af73f996fa7e95f0632dda611f524252f", null ],
    [ "m_pDropTarget", "d0/d11/classwx_s_f_shape_paste_event.html#a69e4aee0c96e666aacc26b52b4aa4334", null ]
];