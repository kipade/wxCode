var classwx_s_f_printout =
[
    [ "wxSFPrintout", "d8/d77/classwx_s_f_printout.html#aaa5d337c305390749d130fcdd40c46d0", null ],
    [ "~wxSFPrintout", "d8/d77/classwx_s_f_printout.html#abef23e98e271b2eba4d90c60956f8eb7", null ],
    [ "GetPageInfo", "d8/d77/classwx_s_f_printout.html#a1eb11148ce619aba6a9e5ecd2d7462ee", null ],
    [ "HasPage", "d8/d77/classwx_s_f_printout.html#a0d5125884edaf476ec1ebdaac817606f", null ],
    [ "OnBeginDocument", "d8/d77/classwx_s_f_printout.html#aa40c265fcd0728d22a6f5ee2802a9f6a", null ],
    [ "OnEndDocument", "d8/d77/classwx_s_f_printout.html#acf44e12fe1c35c17d4a0494d7f11f659", null ],
    [ "OnPrintPage", "d8/d77/classwx_s_f_printout.html#a4e2ed8dc604ee5a7d3a6975637f2dfd3", null ],
    [ "SetPrintedCanvas", "d8/d77/classwx_s_f_printout.html#a8365738ba9bfeee75667cc0e5cd2ba32", null ],
    [ "m_pCanvas", "d8/d77/classwx_s_f_printout.html#a1ca56407a986c2cdcfc0c68a96c0987c", null ]
];