var _control_shape_8h =
[
    [ "sfdvCONTROLSHAPE_CONTROLOFFSET", "db/d2e/_control_shape_8h.html#a23c300a73d3e41b51f92114d6ab5fca5", null ],
    [ "sfdvCONTROLSHAPE_MODBORDER", "db/d2e/_control_shape_8h.html#a84b187e6f789a0d329272b945b3c93f3", null ],
    [ "sfdvCONTROLSHAPE_MODFILL", "db/d2e/_control_shape_8h.html#a7d52e37af21fb8273839f1b397c28abf", null ],
    [ "sfdvCONTROLSHAPE_PROCESSEVENTS", "db/d2e/_control_shape_8h.html#aa8c2e8a5c539d87211cfa1df0be014d1", null ],
    [ "sfFIT_CONTROL_TO_SHAPE", "db/d2e/_control_shape_8h.html#a1ac839ef40ef8b5f9829676e44cf1e26", null ],
    [ "sfFIT_SHAPE_TO_CONTROL", "db/d2e/_control_shape_8h.html#a4b35f8630c23e13251cc962ea970c9b0", null ],
    [ "wxSFControlShape", "db/d2e/_control_shape_8h.html#ad14a7245f1276b64d602e894b4ce5795", null ]
];