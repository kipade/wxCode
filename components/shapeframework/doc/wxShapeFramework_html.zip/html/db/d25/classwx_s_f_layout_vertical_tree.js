var classwx_s_f_layout_vertical_tree =
[
    [ "wxSFLayoutVerticalTree", "db/d25/classwx_s_f_layout_vertical_tree.html#a189cd51ae20b1aa9ff7a983b2dbf9385", null ],
    [ "~wxSFLayoutVerticalTree", "db/d25/classwx_s_f_layout_vertical_tree.html#ad875afa71ed21db9698a7a0d50c51483", null ],
    [ "DoLayout", "db/d25/classwx_s_f_layout_vertical_tree.html#aea963dc677e5d1b66cf43125afae2a51", null ],
    [ "GetHSpace", "db/d25/classwx_s_f_layout_vertical_tree.html#afeb352e853f9aa4ec4b250f070e4f157", null ],
    [ "GetVSpace", "db/d25/classwx_s_f_layout_vertical_tree.html#ad57df8a03f7a242da03093760b8b99ce", null ],
    [ "ProcessNode", "db/d25/classwx_s_f_layout_vertical_tree.html#a9630682cd1153d38f581572a673708c4", null ],
    [ "SetHSpace", "db/d25/classwx_s_f_layout_vertical_tree.html#a90b627573223aa3701abea94726b4f3e", null ],
    [ "SetVSpace", "db/d25/classwx_s_f_layout_vertical_tree.html#a9249e5de0fb1bdac51aa26e045951a13", null ],
    [ "m_HSpace", "db/d25/classwx_s_f_layout_vertical_tree.html#a8b5ec135c843fbb4a76dc9a14a72ebb0", null ],
    [ "m_nCurrMaxWidth", "db/d25/classwx_s_f_layout_vertical_tree.html#a44a070d6c5ce3a5ce79d910309f74658", null ],
    [ "m_nMinX", "db/d25/classwx_s_f_layout_vertical_tree.html#a6106329567b180e6b090bd4d6725451c", null ],
    [ "m_VSpace", "db/d25/classwx_s_f_layout_vertical_tree.html#a422bc78e811cc65665b6c58ae8457b9d", null ]
];