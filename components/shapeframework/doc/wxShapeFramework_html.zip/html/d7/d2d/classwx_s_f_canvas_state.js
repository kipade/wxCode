var classwx_s_f_canvas_state =
[
    [ "wxSFCanvasState", "d7/d2d/classwx_s_f_canvas_state.html#af266252d20bf9b3cbe4b6b180842e521", null ],
    [ "wxSFCanvasState", "d7/d2d/classwx_s_f_canvas_state.html#a9004277e7113b513dd6b49969b1fbde3", null ],
    [ "~wxSFCanvasState", "d7/d2d/classwx_s_f_canvas_state.html#ad0f96c171837c1db55072b8f8498429a", null ],
    [ "Restore", "d7/d2d/classwx_s_f_canvas_state.html#a28af162169cc273b4bf4aa93c6fab1ba", null ],
    [ "wxSFCanvasHistory", "d7/d2d/classwx_s_f_canvas_state.html#a727dae9cc319233d9d107f193c4475ac", null ],
    [ "m_dataBuffer", "d7/d2d/classwx_s_f_canvas_state.html#ac742e3266f48e61f37cb98dcc13f3f32", null ],
    [ "m_pDataManager", "d7/d2d/classwx_s_f_canvas_state.html#a205d493521bdbfd677ddc6d722fc9039", null ]
];