var classwx_s_f_shape_event =
[
    [ "wxSFShapeEvent", "d6/d43/classwx_s_f_shape_event.html#a4bba17914f5fbbbb63d6d2e219359ab7", null ],
    [ "wxSFShapeEvent", "d6/d43/classwx_s_f_shape_event.html#a47406a3944a0aecfa18830aec2e94520", null ],
    [ "~wxSFShapeEvent", "d6/d43/classwx_s_f_shape_event.html#a09991662680a00cad3f8a8efa65ba7cc", null ],
    [ "Clone", "d6/d43/classwx_s_f_shape_event.html#a48062b1f9815be0d70f6351549271db1", null ],
    [ "GetShape", "d6/d43/classwx_s_f_shape_event.html#aa19bd4f74c2042477fcf52ca31cc262d", null ],
    [ "IsVetoed", "d6/d43/classwx_s_f_shape_event.html#a6d4e02819b8b41936f6cc35df18b08e2", null ],
    [ "SetShape", "d6/d43/classwx_s_f_shape_event.html#a7a341cad9882dc7f04a41a93c505c6f1", null ],
    [ "Veto", "d6/d43/classwx_s_f_shape_event.html#a08a669ad329ac889b061f5f292d73548", null ],
    [ "m_Shape", "d6/d43/classwx_s_f_shape_event.html#a429a39c7c6e1cd9ed82df196a2251de4", null ],
    [ "m_Vetoed", "d6/d43/classwx_s_f_shape_event.html#a81e0391782348c77d1c0952a082f6313", null ]
];