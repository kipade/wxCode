var searchData=
[
  ['xmlserializer_2eh',['XmlSerializer.h',['../de/dbb/_xml_serializer_8h.html',1,'']]]
];
