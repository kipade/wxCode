var searchData=
[
  ['halign',['HALIGN',['../da/d88/classwx_s_f_shape_base.html#a7a76ab799b88df9fa0b23c8ba7b4d75b',1,'wxSFShapeBase::HALIGN()'],['../db/d44/classwx_s_f_shape_canvas.html#afe68e5ffc6b55c9760e56973425da5cc',1,'wxSFShapeCanvas::HALIGN()']]],
  ['handletype',['HANDLETYPE',['../d9/dde/classwx_s_f_shape_handle.html#ab6e596fe8bda284c4a851119a2ee2330',1,'wxSFShapeHandle']]]
];
