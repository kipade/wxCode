var searchData=
[
  ['layout',['Layout',['../da/df4/classwx_s_f_auto_layout.html#a4be97e1c0eb694ae406b2c0c34c8328b',1,'wxSFAutoLayout::Layout(ShapeList &amp;shapes, const wxString &amp;algname)'],['../da/df4/classwx_s_f_auto_layout.html#a70ee6a0cbb2e9765820d5629cb5574fd',1,'wxSFAutoLayout::Layout(wxSFDiagramManager &amp;manager, const wxString &amp;algname)'],['../da/df4/classwx_s_f_auto_layout.html#a42df8052c8b2572261bf9608d114a5ca',1,'wxSFAutoLayout::Layout(wxSFShapeCanvas *canvas, const wxString &amp;algname)']]],
  ['linesintersection',['LinesIntersection',['../dd/da2/namespacewx_s_f_common_fcn.html#adb5087a270db7e35f79d25c99537bc26',1,'wxSFCommonFcn']]],
  ['loadcanvas',['LoadCanvas',['../db/d44/classwx_s_f_shape_canvas.html#aafe5fa132939fd055b0638df3d963302',1,'wxSFShapeCanvas']]],
  ['lp2dp',['LP2DP',['../db/d44/classwx_s_f_shape_canvas.html#a3f644b1d6459036cd777f75f2a3d98d4',1,'wxSFShapeCanvas::LP2DP(const wxPoint &amp;pos) const '],['../db/d44/classwx_s_f_shape_canvas.html#abebbf3dc06af9c53a508f2f5cad9bef6',1,'wxSFShapeCanvas::LP2DP(const wxRect &amp;rct) const ']]]
];
