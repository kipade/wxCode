var searchData=
[
  ['findshape',['FindShape',['../d2/d22/classwx_s_f_diagram_manager.html#aa615acf17e8a93c889506051a91ef6d5',1,'wxSFDiagramManager']]],
  ['fitboundingboxtovertices',['FitBoundingBoxToVertices',['../d9/dbd/classwx_s_f_polygon_shape.html#a2c68da68924bcfd3e01e2bbbb7dda1a3',1,'wxSFPolygonShape']]],
  ['fitpositiontogrid',['FitPositionToGrid',['../db/d44/classwx_s_f_shape_canvas.html#aa437977fb7cca62588321c838c8565ca',1,'wxSFShapeCanvas']]],
  ['fitshapetorect',['FitShapeToRect',['../dd/d32/classwx_s_f_grid_shape.html#a54f31ffd2fee97ec7bef036ea7e36ab5',1,'wxSFGridShape']]],
  ['fittochildren',['FitToChildren',['../d0/d60/classwx_s_f_control_shape.html#a92703d49fb3c73ff9b6842af9bc04f4b',1,'wxSFControlShape::FitToChildren()'],['../dd/d32/classwx_s_f_grid_shape.html#ac53b3f0013e0df5a24a9de6ad26f1108',1,'wxSFGridShape::FitToChildren()'],['../d9/dbd/classwx_s_f_polygon_shape.html#a6445bc9df69c949f8dfa1e86deecea63',1,'wxSFPolygonShape::FitToChildren()'],['../db/d0e/classwx_s_f_rect_shape.html#a2633ab3d080a7ee1f18d65c5cd17235c',1,'wxSFRectShape::FitToChildren()'],['../da/d88/classwx_s_f_shape_base.html#a096c82c9dd19b2ea08ac0d778c698282',1,'wxSFShapeBase::FitToChildren()']]],
  ['fitverticestoboundingbox',['FitVerticesToBoundingBox',['../d9/dbd/classwx_s_f_polygon_shape.html#ae240913c7f4303070d4a3ac43ffbe068',1,'wxSFPolygonShape']]],
  ['forcemultiline',['ForceMultiline',['../db/d8d/classwx_s_f_edit_text_shape.html#a528c605935a9e265bdd65f1165889885',1,'wxSFEditTextShape']]],
  ['fromstring',['FromString',['../db/ddf/classxs_property.html#a54d065fee30ebabf3f4a99462bae3f75',1,'xsProperty']]]
];
