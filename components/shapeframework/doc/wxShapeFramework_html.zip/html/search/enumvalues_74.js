var searchData=
[
  ['tsshow_5fconnections',['tsSHOW_CONNECTIONS',['../df/dc2/classwx_s_f_thumbnail.html#a1415f146e2864731da7dd639b1024ed7ae69e0d397c3b44b18f5aedee3cb27d93',1,'wxSFThumbnail']]],
  ['tsshow_5felements',['tsSHOW_ELEMENTS',['../df/dc2/classwx_s_f_thumbnail.html#a1415f146e2864731da7dd639b1024ed7a8729e6d953919f22461c352c6fa745e3',1,'wxSFThumbnail']]]
];
