var searchData=
[
  ['normalizevertices',['NormalizeVertices',['../d9/dbd/classwx_s_f_polygon_shape.html#a8530b0791fc5ec7aaf709612ed9f02c8',1,'wxSFPolygonShape']]]
];
