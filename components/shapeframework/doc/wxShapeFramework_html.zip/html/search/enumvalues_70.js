var searchData=
[
  ['prnfit_5fto_5fmargins',['prnFIT_TO_MARGINS',['../db/d44/classwx_s_f_shape_canvas.html#a5b4948a0b31e9c8fef48d51c34733cf5a2a547a7ea80dae8f6bffb2741d3351a2',1,'wxSFShapeCanvas']]],
  ['prnfit_5fto_5fpage',['prnFIT_TO_PAGE',['../db/d44/classwx_s_f_shape_canvas.html#a5b4948a0b31e9c8fef48d51c34733cf5ac94b5963a7aced104cb0e1d6746f3865',1,'wxSFShapeCanvas']]],
  ['prnfit_5fto_5fpaper',['prnFIT_TO_PAPER',['../db/d44/classwx_s_f_shape_canvas.html#a5b4948a0b31e9c8fef48d51c34733cf5ab3741f389fb9631ba770eea94a64e795',1,'wxSFShapeCanvas']]],
  ['prnmap_5fto_5fdevice',['prnMAP_TO_DEVICE',['../db/d44/classwx_s_f_shape_canvas.html#a5b4948a0b31e9c8fef48d51c34733cf5a0b5bcbcf0110fd387c9ba1df6380751d',1,'wxSFShapeCanvas']]],
  ['prnmap_5fto_5fmargins',['prnMAP_TO_MARGINS',['../db/d44/classwx_s_f_shape_canvas.html#a5b4948a0b31e9c8fef48d51c34733cf5a96c08abd38b32948eb6022d582f2da7d',1,'wxSFShapeCanvas']]],
  ['prnmap_5fto_5fpage',['prnMAP_TO_PAGE',['../db/d44/classwx_s_f_shape_canvas.html#a5b4948a0b31e9c8fef48d51c34733cf5a600217712e44a5abfb34d6943eb8a3b2',1,'wxSFShapeCanvas']]],
  ['prnmap_5fto_5fpaper',['prnMAP_TO_PAPER',['../db/d44/classwx_s_f_shape_canvas.html#a5b4948a0b31e9c8fef48d51c34733cf5a25c61f8171317e9b5ee1f4df89eccd00',1,'wxSFShapeCanvas']]]
];
