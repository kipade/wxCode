var _edit_text_shape_8h =
[
    [ "sfAPPLY_TEXT_CHANGES", "d4/d23/_edit_text_shape_8h.html#a96d592f749089b08bb2cf9e91e8fc653", null ],
    [ "sfCANCEL_TEXT_CHANGES", "d4/d23/_edit_text_shape_8h.html#a81b62183792d6744ce870eb001d2f16d", null ],
    [ "sfdvEDITTEXTSHAPE_EDITTYPE", "d4/d23/_edit_text_shape_8h.html#a33e8c4df40e6ecbf8a9af190ea64c632", null ],
    [ "sfdvEDITTEXTSHAPE_FORCEMULTILINE", "d4/d23/_edit_text_shape_8h.html#ae46b7caf42e8f6ca396ab68f2a7f4f6e", null ],
    [ "wxSFEditTextShape", "d4/d23/_edit_text_shape_8h.html#a9c7ee5d6d14775ce26c4446411d93817", null ]
];