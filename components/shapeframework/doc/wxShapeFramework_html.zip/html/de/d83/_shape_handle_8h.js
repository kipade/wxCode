var _shape_handle_8h =
[
    [ "WX_DECLARE_LIST", "de/d83/_shape_handle_8h.html#aa8088062f88aff35c642d0be092d3620", null ],
    [ "wxSFShapeBase", "de/d83/_shape_handle_8h.html#a625b2b504e999722ca583079656b66ad", null ]
];