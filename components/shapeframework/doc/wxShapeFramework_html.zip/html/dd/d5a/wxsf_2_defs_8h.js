var wxsf_2_defs_8h =
[
    [ "WXDLLIMPEXP_DATA_SF", "dd/d5a/wxsf_2_defs_8h.html#a4c0bfb709a64b3ad15091ec495a9f3f7", null ],
    [ "WXDLLIMPEXP_SF", "dd/d5a/wxsf_2_defs_8h.html#a0bf556e2add13b6c081e79ebd8e0f34e", null ]
];