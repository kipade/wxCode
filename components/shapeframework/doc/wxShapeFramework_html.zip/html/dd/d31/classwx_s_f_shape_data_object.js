var classwx_s_f_shape_data_object =
[
    [ "wxSFShapeDataObject", "dd/d31/classwx_s_f_shape_data_object.html#a806e1fde850ec36c357a266b93478b33", null ],
    [ "wxSFShapeDataObject", "dd/d31/classwx_s_f_shape_data_object.html#acabf32ef5c18171548f8a47729e90bfd", null ],
    [ "~wxSFShapeDataObject", "dd/d31/classwx_s_f_shape_data_object.html#a29dddd35813d7208f3c714cf4dc8adf3", null ],
    [ "GetDataHere", "dd/d31/classwx_s_f_shape_data_object.html#a76ba389a8de90a7870a6c7aad67772ba", null ],
    [ "GetDataSize", "dd/d31/classwx_s_f_shape_data_object.html#ac58cedb54b44962b3d7a4de186409eb0", null ],
    [ "SerializeSelectedShapes", "dd/d31/classwx_s_f_shape_data_object.html#a122ae5b00e848a72d480b2f90d6bb5ca", null ],
    [ "SetData", "dd/d31/classwx_s_f_shape_data_object.html#af0977e32d096eaef936ee79eb37e6206", null ],
    [ "m_Data", "dd/d31/classwx_s_f_shape_data_object.html#a4243f8f056463ae9d44b36eef3d9f6ef", null ]
];